package com.ty.springBoot_FoodApp1.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.springBoot_FoodApp1.dto.Product;

import com.ty.springBoot_FoodApp1.repo.ProductRepo;

@Repository
public class Productdao {
	
@Autowired
	private ProductRepo repo;

public Product saveProduct( Product product) {
    return repo.save(product);
    
  }

public Product updateProduct(int id,Product product) {
	  Product product2=repo.findById(id).get();
	  if(product2!=null) {
		  product2.setPid(id);
		  repo.save(product2);
		  return product2;
	  }else {
		  return null;
	  }
}
	  public Product deleteProduct (int id) {
		  Product product=repo.findById(id).get();
		  if(product!=null) {
			  repo.deleteById(id);
			  return product;
		  }else {
			  return null;
		  }
	
	  } 
	  public  Product getProductById(int id) {
		 Product product=repo.findById(id).get();
		  if(product!=null) {
			return product;
			}else {
				return null;
			}
	  }
}


