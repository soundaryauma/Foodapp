package com.ty.springBoot_FoodApp1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.springBoot_FoodApp1.config.ResponseStructure;
import com.ty.springBoot_FoodApp1.dao.Productdao;
import com.ty.springBoot_FoodApp1.dto.Product;






@Service
public class ProductService {
@Autowired
	private Productdao productdao;
public  ResponseEntity<ResponseStructure<Product> >saveProduct(Product product) {
	ResponseStructure<Product> responsestructure=new ResponseStructure<>();
	  responsestructure.setStatus(HttpStatus.CREATED.value());
	  responsestructure.setMessage("successfully saved");
	  responsestructure.setData(productdao.saveProduct(product));
return  new ResponseEntity<ResponseStructure<Product>>(responsestructure,HttpStatus.CREATED);
}
public ResponseEntity<ResponseStructure<Product>> updateProduct(int id,Product product) {
	 Product product2=productdao.updateProduct(id, product);
	 ResponseStructure<Product> responsestructure=new ResponseStructure<>();
	  if(product2!=null) {
		  responsestructure.setStatus(HttpStatus.OK.value());
		  responsestructure.setMessage("successfully updated");
		  responsestructure.setData(productdao.updateProduct(id, product2));

		  return new ResponseEntity<ResponseStructure<Product>>  (responsestructure,HttpStatus.OK);
	  }else {
		  return null;
	  }
}
public ResponseEntity<ResponseStructure<Product> >deleteProduct (int id) {
    Product product=productdao.deleteProduct(id);
    ResponseStructure<Product> responsestructure=new ResponseStructure<>();
    if(product!=null) {
    	responsestructure.setStatus(HttpStatus.OK.value());
		  responsestructure.setMessage("successfully  deleted");
		  responsestructure.setData(productdao.deleteProduct(id));
         return new ResponseEntity<ResponseStructure<Product>> (responsestructure,HttpStatus.OK);
      
    }
    else {
      return null;
    }
    }
public ResponseEntity <ResponseStructure<Product> >getProductById(int id) {
	 
	Product product=productdao.getProductById(id);
	 ResponseStructure<Product> responsestructure=new ResponseStructure<>();
	  if(product!=null) {
		  responsestructure.setStatus(HttpStatus.FOUND.value());
		  responsestructure.setMessage("successfully  getproductbyid");
		  responsestructure.setData(productdao.getProductById(id));
		return new ResponseEntity<ResponseStructure<Product>>(responsestructure,HttpStatus.OK);
		}else {
			return null;
		}
}
}


