package com.ty.springBoot_FoodApp1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.springBoot_FoodApp1.dto.Product;

public interface ProductRepo extends  JpaRepository<Product, Integer> {

	
}
