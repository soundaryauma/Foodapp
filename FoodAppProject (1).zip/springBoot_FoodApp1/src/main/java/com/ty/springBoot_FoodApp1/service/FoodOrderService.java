package com.ty.springBoot_FoodApp1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ty.springBoot_FoodApp1.config.ResponseStructure;
import com.ty.springBoot_FoodApp1.dao.FoodOrderDao;
import com.ty.springBoot_FoodApp1.dto.FoodOrder;
import com.ty.springBoot_FoodApp1.dto.Items;


@Service
public class FoodOrderService {
@Autowired
	private FoodOrderDao dao;
	
	public ResponseStructure<FoodOrder> saveFoodOrder(FoodOrder foodorder) {
		ResponseStructure<FoodOrder> responsestructure=new ResponseStructure<>();
		List<Items>list=foodorder.getItems();
		double totalprice=0;
		for(Items items:list) {
			totalprice +=items.getCost()*items.getQuantity();
			foodorder.setTotalprice(totalprice);
		}
			
			responsestructure.setStatus(HttpStatus.CREATED.value());
			  responsestructure.setMessage("successfully saved");
			 foodorder.setTotalprice(totalprice);
			return responsestructure;
	}
	
		
         
		
	
	
	public FoodOrder updateFootOrder(FoodOrder foodorder,int id) {
		FoodOrder footorder2=dao.getFootOrder(id);
		if(footorder2!=null) {
			List<Items>list=footorder2.getItems();
			double totalprice=0;
			for(Items items:list) {
				totalprice +=items.getCost()*items.getQuantity();
				foodorder.setTotalprice(totalprice);
			}
			return dao.updateFootOrder(foodorder, id);
		}
		return null;
	}
	public FoodOrder deleteFootOrder(int id) {
		FoodOrder foodorder=dao.deleteFootOrder(id);
		if(foodorder !=null) {
			return foodorder;
		}else {
			return null;
		}
	}
}
