package com.ty.springBoot_FoodApp1.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.springBoot_FoodApp1.dto.FoodOrder;
import com.ty.springBoot_FoodApp1.repo.FoodOrderRepo;

@Repository
public class FoodOrderDao {
	
@Autowired
	private FoodOrderRepo repo;

public FoodOrder saveFoodOrder(FoodOrder foodorder) {
	return repo.save(foodorder);
}
public FoodOrder updateFootOrder(FoodOrder foodorder,int id) {
      Optional <FoodOrder> footorder2=repo.findById(id);
      if(footorder2.isPresent()) {
    	  foodorder.setFid(id);
    	  foodorder.setItems(foodorder.getItems());
    	   repo.save(foodorder);
    	 return footorder2.get();
    	  
    	  
      }else {
    	  return null;
      }
	
}
public FoodOrder getFootOrder(int id) {
	Optional<FoodOrder>footorder=repo.findById(id);
	if(footorder.isPresent()) {
		return footorder.get();
	}
	return null;
}
public FoodOrder deleteFootOrder(int id) {
	Optional<FoodOrder>footorder=repo.findById(id);
	if(footorder.isPresent()) {
		repo.deleteById(id);
		return footorder.get();
	}
	return null;
}
}
