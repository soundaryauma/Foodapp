package com.ty.springBoot_FoodApp1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ty.springBoot_FoodApp1.config.ResponseStructure;
import com.ty.springBoot_FoodApp1.dto.FoodOrder;
import com.ty.springBoot_FoodApp1.service.FoodOrderService;

@RestController
public class FoodOrderController {
@Autowired
	private FoodOrderService service;

@PostMapping("/savefoodorder")
public ResponseStructure<FoodOrder> saveFoodOrder(@RequestBody FoodOrder foodorder) {
	return service.saveFoodOrder(foodorder);
}
@PutMapping("/updatefoodorder")
public FoodOrder updateFootOrder(@RequestBody FoodOrder footorder,@RequestParam int id) {
	return service.updateFootOrder(footorder, id);
}
@DeleteMapping("/deletefoodorder")
public FoodOrder deleteFoodOrder(FoodOrder footorder,int id) {
	return service.deleteFootOrder(id);
}
}
