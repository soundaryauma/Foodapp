package com.ty.springBoot_FoodApp1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ty.springBoot_FoodApp1.config.ResponseStructure;
import com.ty.springBoot_FoodApp1.dao.Menudao;
import com.ty.springBoot_FoodApp1.dto.Menu;


@Service
public class MenuService {
@Autowired
	private Menudao menudao;

public ResponseStructure<Menu> saveMenu(Menu menu) {
	ResponseStructure<Menu> responsestructure=new ResponseStructure<>();
	responsestructure.setStatus(HttpStatus.CREATED.value());
	  responsestructure.setMessage("successfully saved");
	  responsestructure.setData(menudao.saveMenu(menu));
	  return responsestructure;
}

public ResponseStructure<Menu> updateMenu(int id, Menu menu) {
	ResponseStructure<Menu> responsestructure=new ResponseStructure<>();
	Menu menu2=menudao.updateMenu(id, menu);
	if(menu2!=null) {
		responsestructure.setStatus(HttpStatus.OK.value());
		  responsestructure.setMessage("successfully updated");
		  responsestructure.setData(menudao.updateMenu(id, menu2));
		return responsestructure;
	}else {
	return null;
}
}

public ResponseStructure<Menu> deleteMenu(int mid) {
	ResponseStructure<Menu> responsestructure=new ResponseStructure<>();
Menu menu=menudao.deleteMenu(mid);
if(menu!=null) {
	responsestructure.setStatus(HttpStatus.OK.value());
	  responsestructure.setMessage("successfully deleted");
	  responsestructure.setData(menudao.deleteMenu(mid));
	return responsestructure;
}else {
	return null;
}
}
public ResponseStructure<Menu> getMenuById(int mid) {
	ResponseStructure<Menu> responsestructure=new ResponseStructure<>();
	Menu menu=menudao.getMenuById(mid);
	if(menu!=null) {
		responsestructure.setStatus(HttpStatus.FOUND.value());
		  responsestructure.setMessage("successfully getmenubyid");
		  responsestructure.setData(menudao.getMenuById(mid));
		return responsestructure;
	}else {
		return null;
	}
}
}





