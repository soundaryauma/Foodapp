package com.ty.springBoot_FoodApp1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JacksonInject.Value;
import com.ty.springBoot_FoodApp1.config.ResponseStructure;
import com.ty.springBoot_FoodApp1.dto.User;
import com.ty.springBoot_FoodApp1.service.UserService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RestController
public class UserController{

@Autowired
	private UserService service;

@ApiOperation (value ="save user",notes="API is used to save user for given user id")
@ApiResponses (value= {@ApiResponse(code=201,message="successfully saved"),
		@ApiResponse(code=400,message="id not found for the given user id")})


@PostMapping
public ResponseEntity <ResponseStructure<User>>  saveUser(@RequestBody User user) {
	return service.saveUser(user);
	
}
@ApiOperation (value ="update user",notes="API is used to update user for given user id")
@ApiResponses (value= {@ApiResponse(code=201,message="successfully saved"),
		@ApiResponse(code=400,message="id not found for the given user id")})

@PutMapping
public ResponseEntity<ResponseStructure<User>> updateUser(@RequestParam int id,@RequestBody User user) {
	return service.updateUser(id, user);
}
@ApiOperation (value ="delete user",notes="API is used to delete user for given user id")
		 @ApiResponses (value= {@ApiResponse(code=201,message="successfully saved"),
		@ApiResponse(code=400,message="id not found for the given user id")})

@DeleteMapping("/id")
public ResponseEntity	<ResponseStructure<User>> deleteUser(@RequestParam int id) {
	return service.deleteUser(id);
}

@GetMapping("/getuserbyid")
public  ResponseEntity<ResponseStructure<User>> getUserById(@RequestParam int id) {
	return service.getUserById(id);
}
}
