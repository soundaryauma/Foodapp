package com.ty.springBoot_FoodApp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFoodApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFoodApp1Application.class, args);
	}

}
