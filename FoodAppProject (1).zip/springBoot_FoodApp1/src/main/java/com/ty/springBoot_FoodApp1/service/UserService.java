package com.ty.springBoot_FoodApp1.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.springBoot_FoodApp1.Exception.UserIdNotFoundException;
import com.ty.springBoot_FoodApp1.config.ResponseStructure;
import com.ty.springBoot_FoodApp1.dao.UserDao;
	import com.ty.springBoot_FoodApp1.dto.User;

	@Service
	public class UserService {

	  
	  @Autowired
	  private UserDao dao;
	  
	  public  ResponseEntity<ResponseStructure<User> >saveUser(User user) {
		  ResponseStructure<User> responsestructure=new ResponseStructure<>();
		  responsestructure.setStatus(HttpStatus.CREATED.value());
		  responsestructure.setMessage("user successfully saved");
		  responsestructure.setData(dao.saveUser(user));
		  return  new ResponseEntity<ResponseStructure<User> >(responsestructure,HttpStatus.CREATED);
	    
	  }
	  public ResponseEntity<ResponseStructure<User>> updateUser(int id,User user) {
		  User user2=dao.updateUser(id, user);
		  ResponseStructure<User> responsestructure=new ResponseStructure<>();
		  if(user2!=null) {
			  responsestructure.setStatus(HttpStatus.OK.value());
			  responsestructure.setMessage("user successfully updated");
			  responsestructure.setData(dao.updateUser(id, user2));
			  return new ResponseEntity<ResponseStructure<User>>  (responsestructure,HttpStatus.OK);
			  
		  }else {
			  return null;
		  }
	  }
	  public ResponseEntity<ResponseStructure<User> >deleteUser (int id) {
		    User user=dao.deleteUser(id);
		    ResponseStructure<User> responsestructure=new ResponseStructure<>();
		    if(user!=null) {
		    	 responsestructure.setStatus(HttpStatus.OK.value());
				  responsestructure.setMessage("user successfully deleted");
				  responsestructure.setData(dao.deleteUser(id));
				  return  new ResponseEntity<ResponseStructure <User>> (responsestructure,HttpStatus.OK);
		      
		      
		    }
		    else {
		      return null;
		    }
		    }
	  public  ResponseEntity<ResponseStructure<User>> getUserById(int id) {
		  User user=dao.getUserById(id);
		  ResponseStructure<User> responsestructure=new ResponseStructure<>();
		  if(user!=null) {
			  responsestructure.setStatus(HttpStatus.FOUND.value());
			  responsestructure.setMessage("user successfully getuserbyid");
			  responsestructure.setData(dao.getUserById(id));
			  return  new ResponseEntity<ResponseStructure<User>> (responsestructure,HttpStatus.OK);
			
			}else {
				throw new UserIdNotFoundException("user id is not present");
			}
	  }
}
		  
		    
		 
		    
	

