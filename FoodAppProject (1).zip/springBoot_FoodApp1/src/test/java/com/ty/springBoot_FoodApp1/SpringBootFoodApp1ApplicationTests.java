package com.ty.springBoot_FoodApp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFoodApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
